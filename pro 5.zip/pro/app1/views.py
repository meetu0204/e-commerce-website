from django.shortcuts import render,HttpResponse,redirect
from .models import *
# Create your views here.

def first(request):
    return HttpResponse("this is my first view function..")


def demo(request):
    return render(request,'demo.html')

# read operation - admin to user
 
def table(request):
    a = Blog.objects.all()
    # print(a)
    # for i in a:
    return render(request,'table.html',{'blog':a})

# read operation with image - admin to user

def catdata(request):
    cat = category.objects.all()
    return render(request,'cattable.html',{'cat':cat})


# creat operation : user - admin

def form(request):
    if request.method == 'POST':
        auth = Author()
        auth.name = request.POST['uname']
        auth.email = request.POST['uemail']
        auth.save()
    return render(request,'form.html')

# creat operation : user - admin

from django.core.mail import send_mail

def regform(request):
    if request.method == 'POST':
        reg = Register()
        reg.name = request.POST['uname']
        reg.email = request.POST['uemail']
        reg.add = request.POST['add']
        reg.mob = request.POST['mob']
        reg.password = request.POST['pass']
        reg.save()
        print("data saveedd")
    return render(request,'regform.html')

# creat operation with image : user - admin


def catform(request):
    if request.method == 'POST' and request.FILES:
        cat = category()
        cat.name = request.POST['catname']
        cat.image = request.FILES['img']
        cat.save()
    return render(request,'catform.html')

def userreg(request):
    if request.method == 'POST':
        userdata = Register()
        userdata.name = request.POST['uname']
        userdata.email = request.POST['email']
        userdata.mob = request.POST['mob']
        userdata.add = request.POST['add']
        userdata.password = request.POST['password']
        already = Register.objects.filter(email = request.POST['email'])
        if already:
            return render(request,'register.html',{'already':'email already exists!!'})
        else:
        # if Register.objects.filter(email = request.POST['email']):
            userdata.save()
            
            print("email senttt")
            return render(request,'register.html',{'save':'data stored successfully'})
    else:
        return render(request,'register.html')

import random
from django.core.exceptions import ObjectDoesNotExist,MultipleObjectsReturned

def login(request):
    if request.method == 'POST':
        a = 58
        try:
            userdata = Register.objects.get(email = request.POST['email'])
            # print(userdata.name,userdata.password,userdata.mob,"11111111111")
            if userdata.password == request.POST['password']:
                request.session['email'] = userdata.email
                print("login successfulll")
                # return render(request,'login.html')
                # otp = random.randint(100,999)
                # request.session['otp'] = otp
                # send_mail(
                #     'Welcome message from our website',
                #     f'Your OTP for login of emcommerce is {otp}',
                #     'pqr6997@gmail.com',
                #     [userdata.email],
                #     fail_silently = False
                # )
                return redirect('index')
        except ObjectDoesNotExist:
            return render(request,'login.html',{'notregistered':"you havent registered yet"})
        except  MultipleObjectsReturned:
            return render(request,'login.html',{'multipleregisterd':"More the one time registered!!"})

        else:
            print("login not successfull")
            return render(request,'login.html',{'password':'Invaid password!!'})        
    else:
        return render(request,'login.html')
    

def otp(request):
    if request.method == 'POST':
        if int(request.session['otp']) == int(request.POST['otp']):
            return redirect('index')
        else:
            return render(request,'otp.html',{'invalidotp':"The otp you enter does not matched!!"})
    else:
        return render(request,'otp.html')


def index(request):
    if 'email' in request.session:
        cat = category.objects.all()
        print(cat)
        return render(request,'index.html',{'loggedin':True,'cat':cat})
    else:
        cat = category.objects.all()
        return render(request,'index.html',{'cat':cat})


def logout(request):
    del request.session['email']
    return redirect('login')


def proall(request):
    if 'email' in request.session:
        pro = product.objects.all()
        return render(request,'proall.html',{'pro':pro,'loggedin':True})
    else:
        pro = product.objects.all()
        return render(request,'proall.html',{'pro':pro})

def procat(request,id):
    if 'email' in request.session:
        procat = product.objects.filter(category = id) 
        return render(request,'procat.html',{'procat':procat,"loggedin":True})
    else:
        procat = product.objects.filter(category = id) 
        return render(request,'procat.html',{'procat':procat})



def prodetails(request,id):
    if 'email' in request.session:
        loggedinuser = Register.objects.get(email = request.session['email'])
        prodetail = product.objects.get(id = id)
        if  'buy' in request.POST : 
            if prodetail.stock <= 0:
                    return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'0stock':"Kale avjee!!, after restock"})
            else:
                if int(request.POST['qty']) > int(prodetail.stock):
                    return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'outofstock':"ochii krr!!"})
                else:
                    request.session['proid'] = prodetail.pk
                    request.session['buyqty'] = request.POST['qty']
                    return redirect('checkout')
        elif 'cart' in request.POST :
            if  int(prodetail.stock) <= 0:
                return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'0stock':"Kale avjee!!, after restock"})
            else:
                cartdata = cart()
                cartdata.proid = prodetail.pk
                cartdata.userid = loggedinuser.pk
                cartdata.qty = request.POST['qty']
                if int(cartdata.qty) > int(prodetail.stock):
                    return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'outofstock':"ochii krr!!"})
                else:
                    cartdata.totalprice = int(prodetail.price) * int(request.POST['qty'])
                    already_cart = cart.objects.filter(proid = id,userid = loggedinuser.id)
                    if already_cart:
                        # return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'already_cart':"chejjj!!!"})
                        already = cart.objects.get(proid = id,userid = loggedinuser.id)
                        already.qty = int(already.qty) + int(cartdata.qty) 
                        already.totalprice = int(already.totalprice) + int(prodetail.price) * int(request.POST['qty'])
                        prodetail.stock = int(prodetail.stock) - int(cartdata.qty)
                        prodetail.save()
                        already.save()
                        return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'already_cart':"chejjj!!!"})
                    else:
                        prodetail.stock = int(prodetail.stock) - int(cartdata.qty)
                        cartdata.save()
                        prodetail.save()
                        return redirect('cart')
        else:
            return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True})
    else:
        # prodetail = product.objects.get(id = id)

        # return render(request,'prodetails.html',{'prodetail':prodetail})
        return redirect('login')
    

def profile(request):
    pro = Register.objects.get(email = request.session['email'])
    if request.method == 'POST':
        pro.name = request.POST['uname']
        pro.email =  request.POST['email']
        pro.mob = request.POST['mob']
        pro.add = request.POST['add']
        pro.save()
    return render(request,'profile.html',{'pro':pro})


def checkout(request):
    if 'email' in request.session:
        registeruser = Register.objects.get(email = request.session['email'] )
        pro = product.objects.get(id = request.session['proid'])
        qty = request.session['buyqty']
        totalprice = int(pro.price) * int(request.session['buyqty'])
        if request.method == 'POST':
            orderdata = order()
            orderdata.proid = pro.id 
            orderdata.userid = registeruser.pk
            orderdata.add = request.POST['add']
            orderdata.state = request.POST['state'] 
            orderdata.city = request.POST['city']
            orderdata.pincode = request.POST['pin']
            orderdata.totalprice = totalprice
            orderdata.qty = qty
            orderdata.paytype  = request.POST['paymentvia']
            orderdata.transaction_id = "1234"
            if orderdata.paytype == "cod":
                orderdata.save()
                pro.stock = int(pro.stock) - int(qty)
                pro.save()
            else:
                request.session['amount'] = totalprice
                request.session['add'] = request.POST['add']
                request.session['state'] = request.POST['state'] 
                request.session['city'] = request.POST['pin']
                request.session['pin'] = request.POST['pin']
                return redirect('razorpay')
            return redirect('orderplaced')
        else:
            return render(request,'checkout.html',{"loggedin":True,'user':registeruser,'pro':pro,'qty':qty,'totalprice':totalprice})
    else:
        return redirect('login')
    

def orderplaced(request):
    return render(request,'ordereds.html')


RAZOR_KEY_ID = "rzp_test_7OImT75w0b3T5s"
RAZOR_KEY_SECRET = "2DyOadFeAUMu9vGCg2RFMXKj"

import razorpay

razorpay_client = razorpay.Client(
    auth=(RAZOR_KEY_ID, RAZOR_KEY_SECRET))


def razorpayment(request):
    currency = 'INR'
    amount = int(request.session['amount']) * 100

    razorpay_order = razorpay_client.order.create(dict(currency = currency,amount = amount,payment_capture = '0'))
    razorpay_order_id = razorpay_order['id']
    callback_url = 'http://127.0.0.1:8000/paymenthandler/'
    return render(request,'razorpay.html',{'currency':currency,'amount':amount,'razorpay_order':razorpay_order,
                                           'razorpay_order_id':razorpay_order_id,'callback_url':callback_url,
                                           "RAZOR_KEY_ID":RAZOR_KEY_ID})

from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def paymenthandler(request):
    loggedinuser = Register.objects.get(email = request.session['email'])
    if request.method == "POST":
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')

            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
 
            result = razorpay_client.utility.verify_payment_signature(params_dict)
            razorpay_client.payment.capture(payment_id, int(request.session['amount']) * 100)
            orderdata = order()
            orderdata.proid = request.session['proid']
            orderdata.userid = loggedinuser.pk
            orderdata.add = request.session['add']
            orderdata.city = request.session['city']
            orderdata.state = request.session['state'] 
            orderdata.pincode = request.session['pin']
            orderdata.totalprice = int(request.session['amount'])
            orderdata.qty = request.session['buyqty']
            orderdata.paytype = "Online"
            orderdata.transaction_id = payment_id
            orderdata.save()
            return HttpResponse("Payment successfull")
    else:
        return HttpResponse("Invalid data")


def cartdata(request):
    if 'email' in request.session:
        prolist = []
        loggedin_user = Register.objects.get(
            email = request.session['email'])
        
        proincart = cart.objects.filter(userid = loggedin_user.id)

        if proincart:
            cartpro = cart.objects.filter(
                userid = loggedin_user.id)
            
            grand_total = 0
            for i in cartpro:
                pro = product.objects.get(id = i.proid)
                prodict = {'proimg':pro.image,'proname':pro.name
                        ,'proprice':pro.price,
                        'totalprice':i.totalprice,'qty':i.qty}
                grand_total += i.totalprice
                prolist.append(prodict)
            return render(request,'cart.html',{'loggedin':True,'prolist':prolist,'grandtotal':grand_total})
        else:
            return render(request,'cart.html',{'loggedin':True,'emptycart':"Your cart is empty ;("})
    else:
        return redirect('login')