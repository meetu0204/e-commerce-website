from django.contrib import admin
from .models import Blog,Author,Register
# Register your models here.


class Blog_(admin.ModelAdmin):
    list_display = ['name','tagline']

admin.site.register(Blog,Blog_)

class Reg_(admin.ModelAdmin):
    list_display = ['name','email','mob','add']

admin.site.register(Register,Reg_)