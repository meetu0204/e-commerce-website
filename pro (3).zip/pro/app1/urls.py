from django.contrib import admin
from django.urls import path,include
from .views import *

urlpatterns = [
    path('first/',first,name="first"),
    path('demo/',demo,name='demo'),
    path('table/',table,name='table'),
    path('cat/',catdata,name='catadata'),
    path('form/',form,name='form'),
    path('regform/',regform,name='regform'),
    path('catform/',catform,name='catform'),
    path('register/',userreg,name='userreg'),
    path('',index,name='index'),
    path('login/',login,name="login"),
    path('logout/',logout,name='logout'),
    path('proall/',proall,name='proall'),
    path('procat/<int:id>',procat,name='procat'),
    path('prodetails/<int:id>',prodetails,name='prodetails'),
    path('profile/',profile,name='profile'),
    path('checkout/',checkout,name='checkout'),
    path('orderplaced/',orderplaced,name= 'orderplaced')


]