from django.contrib import admin
from .models import *
# Register your models here.


class Blog_(admin.ModelAdmin):
    list_display = ['id','name','tagline']

admin.site.register(Blog,Blog_)


class auth_(admin.ModelAdmin):
    list_display = ['id','name','email']

admin.site.register(Author,auth_)


class Reg_(admin.ModelAdmin):
    list_display = ['id','name','email','mob','add']

admin.site.register(Register,Reg_)

class cat_(admin.ModelAdmin):
    list_display = ['id','name','image']

admin.site.register(category,cat_)

class pro_(admin.ModelAdmin):
    list_display = ['id','name','category','price','stock']

admin.site.register(product,pro_)

class order_(admin.ModelAdmin):
    list_display = ['id','userid','proid','totalprice','qty','datetime','paytype','transaction_id']

admin.site.register(order,order_)