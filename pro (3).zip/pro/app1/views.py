from django.shortcuts import render,HttpResponse,redirect
from .models import *
# Create your views here.

def first(request):
    return HttpResponse("this is my first view function..")


def demo(request):
    return render(request,'demo.html')

# read operation - admin to user
 
def table(request):
    a = Blog.objects.all()
    # print(a)
    # for i in a:
    return render(request,'table.html',{'blog':a})

# read operation with image - admin to user

def catdata(request):
    cat = category.objects.all()
    return render(request,'cattable.html',{'cat':cat})


# creat operation : user - admin

def form(request):
    if request.method == 'POST':
        auth = Author()
        auth.name = request.POST['uname']
        auth.email = request.POST['uemail']
        auth.save()
    return render(request,'form.html')

# creat operation : user - admin


def regform(request):
    if request.method == 'POST':
        reg = Register()
        reg.name = request.POST['uname']
        reg.email = request.POST['uemail']
        reg.add = request.POST['add']
        reg.mob = request.POST['mob']
        reg.password = request.POST['pass']
        reg.save()
    return render(request,'regform.html')

# creat operation with image : user - admin


def catform(request):
    if request.method == 'POST' and request.FILES:
        cat = category()
        cat.name = request.POST['catname']
        cat.image = request.FILES['img']
        cat.save()
    return render(request,'catform.html')

def userreg(request):
    if request.method == 'POST':
        userdata = Register()
        userdata.name = request.POST['uname']
        userdata.email = request.POST['email']
        userdata.mob = request.POST['mob']
        userdata.add = request.POST['add']
        userdata.password = request.POST['password']
        already = Register.objects.filter(email = request.POST['email'])
        if already:
            return render(request,'register.html',{'already':'email already exists!!'})
        else:
        # if Register.objects.filter(email = request.POST['email']):
            userdata.save()
            return render(request,'register.html',{'save':'data stored successfully'})
    else:
        return render(request,'register.html')






def login(request):
    if request.method == 'POST':
        a = 58
        userdata = Register.objects.get(email = request.POST['email'])
        # print(userdata.name,userdata.password,userdata.mob,"11111111111")
        if userdata.password == request.POST['password']:
            request.session['email'] = userdata.email
            print("login successfulll")
            # return render(request,'login.html')
            return redirect('index')
        else:
            print("login not successfull")
            return render(request,'login.html',{'password':'Invaid password!!'})        
    else:
        return render(request,'login.html')


def index(request):
    if 'email' in request.session:
        cat = category.objects.all()
        print(cat)
        return render(request,'index.html',{'loggedin':True,'cat':cat})
    else:
        cat = category.objects.all()
        return render(request,'index.html',{'cat':cat})


def logout(request):
    del request.session['email']
    return redirect('login')


def proall(request):
    if 'email' in request.session:
        pro = product.objects.all()
        return render(request,'proall.html',{'pro':pro,'loggedin':True})
    else:
        pro = product.objects.all()
        return render(request,'proall.html',{'pro':pro})

def procat(request,id):
    if 'email' in request.session:
        procat = product.objects.filter(category = id) 
        return render(request,'procat.html',{'procat':procat,"loggedin":True})
    else:
        procat = product.objects.filter(category = id) 
        return render(request,'procat.html',{'procat':procat})



def prodetails(request,id):
    if 'email' in request.session:
        prodetail = product.objects.get(id = id)
        if request.method == 'POST':
            if prodetail.stock <= 0:
                    return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'0stock':"Kale avjee!!, after restock"})
            else:
                if int(request.POST['qty']) > int(prodetail.stock):
                    return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True,'outofstock':"ochii krr!!"})
                else:
                    request.session['proid'] = prodetail.pk
                    request.session['buyqty'] = request.POST['qty']
                    return redirect('checkout')
        else:
            return render(request,'prodetails.html',{'prodetail':prodetail,"loggedin":True})
    else:
        prodetail = product.objects.get(id = id)

        return render(request,'prodetails.html',{'prodetail':prodetail})
    

def profile(request):
    pro = Register.objects.get(email = request.session['email'])
    if request.method == 'POST':
        pro.name = request.POST['uname']
        pro.email =  request.POST['email']
        pro.mob = request.POST['mob']
        pro.add = request.POST['add']
        pro.save()
    return render(request,'profile.html',{'pro':pro})


def checkout(request):
    if 'email' in request.session:
        registeruser = Register.objects.get(email = request.session['email'] )
        pro = product.objects.get(id = request.session['proid'])
        qty = request.session['buyqty']
        totalprice = int(pro.price) * int(request.session['buyqty'])
        if request.method == 'POST':
            orderdata = order()
            orderdata.proid = pro.id 
            orderdata.userid = registeruser.pk
            orderdata.add = request.POST['add']
            orderdata.state = request.POST['state'] 
            orderdata.city = request.POST['city']
            orderdata.pincode = request.POST['pin']
            orderdata.totalprice = totalprice
            orderdata.qty = qty
            orderdata.paytype  = request.POST['paymentvia']
            orderdata.transaction_id = "1234"
            orderdata.save()
            pro.stock = int(pro.stock) - int(qty)
            pro.save()
            return redirect('orderplaced')
        else:
            return render(request,'checkout.html',{"loggedin":True,'user':registeruser,'pro':pro,'qty':qty,'totalprice':totalprice})
    else:
        return redirect('login')
    

def orderplaced(request):
    return render(request,'ordereds.html')